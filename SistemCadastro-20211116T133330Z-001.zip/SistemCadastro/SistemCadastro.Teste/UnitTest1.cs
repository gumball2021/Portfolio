using Dominio.Cargos;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SistemCadastro.Teste
{
    [TestClass]
    public class UnitTest1
    {
        //        [TestMethod]
        //        //public void DeveRetornarNotificacaoQuandoOCampoNaoForValido()
        //        //{
        //        //    var nomeCargo = new Cargo("");
        //        //    Assert.AreEqual(false, nomeCargo.Invalid);
        //        //    Assert.AreNotEqual(string.Empty, nomeCargo.Notifications.Count);
        //        //}
        //        //[TestMethod]                                             
        //        //public void DeveRetornarNotificacaoQuandoOCampoForValido()
        //        //{
        //        //    var nomeCargo = new Cargo("infra") ;
        //        //    Assert.AreEqual(true, nomeCargo.Valid);
        //        //    Assert.AreEqual(0, nomeCargo.Notifications.Count);
        ////        }
        //   }
    }
}

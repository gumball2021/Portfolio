﻿using System;

namespace Servico
{
    public class Class1
    {
    }
}

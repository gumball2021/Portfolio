﻿using Dominio.Cargos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Protocols;
using SistemCadastro.Dominio.Cargos.Fluxo;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using SistemCadastro.Infraestrutura.Contextos.Cargo.QueryAjuda;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SistemInventario.Api.Contexto
{
    [Route("api/[controller]")]
    public class CargoController : Controller
    {


        [HttpPost]
        public ActionResult Post([FromBody]Cargo cargo)
        {

            if (cargo.NomeCargo == null)
                return BadRequest(new { Sucesso = false, Mensagem = "Cargo obrigatório." });

            var retorno = CargoFluxo.CriarUmNovoCargo(cargo);

            if (retorno == true)
            {
                return Ok(new { StatusCode = 201, Sucesso = true, Mensagem = "Salvo com sucesso!" });
            }
            else
                return NoContent();
        }

        [HttpGet]
        [Route("v1/buscar/{Id}")]
        public ActionResult<Cargo> ListarPorId(int Id)
        {


            if (Id <= 0)
                return BadRequest(new { Sucesso = false, Mensagem = "Id é incorreto." });

            var retorno = CargoFluxo.ListarPorId(Id);

            return retorno;
        }

        // get: api/<controller>
        [HttpGet]
        [Route("v1/buscar")]

        public List<Cargo> ListarTodos(string NomeCargo)
        {

            var retorno = CargoFluxo.ListarTodos(NomeCargo);

            return retorno;
        }

        
        [HttpPut]
        [Route("v1/buscar/{Id}")]
        public ActionResult Put([FromBody]Cargo cargo)
        {
             var retorno = CargoFluxo.Alterar(NomeCargo);
            return retorno;
        }

        [HttpDelete]
        [Route("v1/buscar/{Id}")]
        public object Delete()
        {
            return new { message = "Cargo removido!" };
        }


    }
}


﻿using Dominio.Equipamento;
using Microsoft.AspNetCore.Mvc;
using SistemCadastro.Dominio.Equipamentos.Fluxo;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SistemInventario.Api.Contexto
{

    [Route("api/[controller]")]
    [ApiController]
    public class EquipamentoController : ControllerBase
    {

        [HttpPost]
        public string Post([FromBody] Equipamento equipamento)
        {
            EquipamentoFluxo.CriarUmNovoEquipamento(equipamento);

            
            if (equipamento.DataGarantia == null)
            {
                return "A data do cadastro é obrigatório.";
            }

            return "Salvo com sucesso!";
        }
        [HttpGet]
        [Route("v1/buscar")]

        public List<Equipamento> ListarTodos(string NomeEquipamento)
        {

            var retorno = EquipamentoFluxo.ListarTodos(NomeEquipamento);

            return retorno;
        }
        [HttpPut]
        [Route("v1/buscar/{Id}")]
        public ActionResult Put([FromBody]Equipamento equipamento)
        {
             var retorno = EquipamentoFluxo.Alterar(NomeEquipamento, DataGarantia, DataCompra);
            return retorno;
        }

        [HttpDelete]
        [Route("v1/buscar/{Id}")]
        public object Delete()
        {
            return new { message = "Equipamento removido!" };
        }



    }
}

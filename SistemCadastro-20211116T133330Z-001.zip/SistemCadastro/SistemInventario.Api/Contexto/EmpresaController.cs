﻿using Dominio.Empresa;
using Microsoft.AspNetCore.Mvc;
using SistemCadastro.Dominio.Empresas.Fluxo;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SistemInventario.Api.Contexto
{
    [Route("api/[controller]")]
    public class EmpresaController : Controller
    {
        [HttpPost]
        public ActionResult Post([FromBody]Empresa empresa)
        {
            if (empresa.NomeEmpresa == null)
                return BadRequest(new { Sucesso = false, Mensagem = "O nome da empresa é obrigatório." });

            var retorno = EmpresaFluxo.CriarUmaNovaEmpresa(empresa);

            if(retorno == true)
            {
            return Ok(new { StatusCode = 201, Sucesso = true, Mensagem = "Salvo com sucesso!" } );
            }
            else
                return NoContent();

        }
        [HttpGet]
        [Route("v1/buscar")]

        public List<Empresa> ListarTodos(string NomeEmpresa)
        {

            var retorno = EmpresaFluxo.ListarTodos(NomeEmpresa);

            return retorno;
        }
        [HttpPut]
        [Route("v1/buscar/{Id}")]
        public ActionResult Put([FromBody]Empresa empresa)
        {
             var retorno = EmpresaFluxo.Alterar(NomeEmpresa);
            return retorno;
        }

        [HttpDelete]
        [Route("v1/buscar/{Id}")]
        public object Delete()
        {
            return new { message = "Empresa removida!" };
        }

    }
}

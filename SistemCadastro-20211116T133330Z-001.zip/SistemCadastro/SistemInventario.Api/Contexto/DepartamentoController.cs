﻿using Microsoft.AspNetCore.Mvc;
using SistemCadastro.Dominio.Departamentos;
using SistemCadastro.Dominio.Departamentos.Fluxo;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SistemInventario.Api.Contexto
{
    [Route("api/[controller]")]
    public class DepartamentoController : Controller
    {
        [HttpPost]
        public ActionResult Post([FromBody]Departamento departamento)
        {
            if (departamento.NomeDep == null)
                return BadRequest(new { Sucesso = false, Mensagem = "Departamento obrigatório." });

            var retorno = DepartamentoFluxo.CriarUmNovoDepartamento(departamento);

            if (retorno == true)
            {
                return Ok(new { StatusCode = 201, Sucesso = true, Mensagem = "Salvo com sucesso!" });
            }
            else
                return NoContent();
        }
        [HttpGet]
        [Route("v1/buscar/{Id}")]
        public ActionResult<Departamento> ListarPorId(int Id)
        {

            if (Id <= 0)
                return BadRequest(new { Sucesso = false, Mensagem = "Id é incorreto." });

            var retorno = DepartamentoFluxo.ListarPorId(Id);

            return retorno;
        }
        [HttpGet]
        [Route("v1/buscar")]

        public List<Departamento> ListarTodos(string NomeDep)
        {

            var retorno = DepartamentoFluxo.ListarTodos(NomeDep);

            return retorno;
        }
        [HttpPut]
        [Route("v1/buscar/{Id}")]
        public ActionResult Put([FromBody]Departamento departamento)
        {
             var retorno = CargoFluxo.Alterar(NomeDep);
            return retorno;
        }

        [HttpDelete]
        [Route("v1/buscar/{Id}")]
        public object Delete()
        {
            return new { message = "Departamento removido!" };
        }

    }
       
    }


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dominio.Especificacao;
using Microsoft.AspNetCore.Mvc;
using SistemCadastro.Dominio.Especificacoes.Fluxo;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SistemInventario.Api.Contexto
{
    [Route("api/[controller]")]
    public class EspecificacaoController : Controller
    {
        [HttpPost]
        public ActionResult Post([FromBody]Especificacao especificacao)
        {
            EspecificacaoFluxo.CriarUmaNovaEspecificacao(especificacao);
            return CreatedAtAction("", new { Sucesso = true, Mensagem = "Salvo com sucesso!" });
        }
        [HttpGet]
        [Route("v1/buscar")]

        public List<Especificacao> ListarTodos()
        {

            var retorno = EspecificacaoFluxo.ListarTodos();

            return retorno;
        }




        //// GET: api/<controller>
        //[HttpGet]
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        //// GET api/<controller>/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        //// POST api/<controller>
        //[HttpPost]
        //public void Post([FromBody]string value)
        //{
        //}

        //// PUT api/<controller>/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody]string value)
        //{
        //}

        //// DELETE api/<controller>/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}

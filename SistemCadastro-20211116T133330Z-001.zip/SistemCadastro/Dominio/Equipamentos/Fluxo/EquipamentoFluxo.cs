﻿using Dominio.Equipamento;
using SistemCadastro.Dominio.Equipamentos.Repositorio;
using System;
using System.Collections.Generic;
using System.Text;

namespace SistemCadastro.Dominio.Equipamentos.Fluxo
{
    public class EquipamentoFluxo
    {
        public static bool CriarUmNovoEquipamento(Equipamento equipamento)
        {
            var equipamentoRepo = new EquipamentoRepositorio();
            var retorno = equipamentoRepo.CriarNovoEquipamento(equipamento);
            if (retorno > 0)
                return true;

            return false;
        }

        public static Equipamento ListarPorId(int Id)
        {
            var equipamentoRepo = new EquipamentoRepositorio();

            var resultado = equipamentoRepo.ListarPorId(Id);

            return resultado;
        }
        public static List<Equipamento> ListarTodos(string NomeEquipamento)
        {
            var equipamentoRepo = new EquipamentoRepositorio();
            var resultado = equipamentoRepo.ListarTodos(NomeEquipamento);

            return resultado;
        }
         public static Equipamento Alterar(string NomeEquipamento, DateTime DataGarantia, DateTime DataCompra)
        {   
            var equipamentoRepo = new EquipamentoRepositorio();
            var resultado = equipamentoRepo.AlterarEquipamento(NomeEquipamento, DataGarantia, DataCompra);

            return resultado;
        }
        public static Equipamento Excluir()
        {   
            var equipamentoRepo = new EquipamentoRepositorio();
            var resultado = equipamentoRepo.ExcluirEquipamento();

            return resultado;
        }
    }
}

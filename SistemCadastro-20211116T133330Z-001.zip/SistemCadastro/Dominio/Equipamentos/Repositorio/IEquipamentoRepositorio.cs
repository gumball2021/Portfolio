﻿using Dominio.Equipamento;
using System.Collections.Generic;

namespace SistemCadastro.Dominio.Equipamentos.Repositorio
{
    public interface IEquipamentoRepositorio
    {
        bool AlterarEquipamento(Equipamento equipamento);
        long CriarNovoEquipamento(Equipamento equipamento);
        bool ExcluirEquipamento(Equipamento equipamento);
        Equipamento ListarPorId(int Id);
        List<Equipamento> ListarTodos(string NomeEquipamento);
    }
}

﻿using Dapper;
using Dapper.Contrib.Extensions;
using Dominio.Equipamento;
using SistemCadastro.Infraestrutura.Contextos.Equipamento.QueryAjuda;
using SistemCadastro.Infraestrutura.Dados.Contexto;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SistemCadastro.Dominio.Equipamentos.Repositorio
{
    public class EquipamentoRepositorio : IEquipamentoRepositorio
    {
        public ContextoBanco ContextoDapper { get; set; }
        public EquipamentoRepositorio()
        {
            ContextoDapper = new ContextoBanco();
        }

        public bool AlterarEquipamento(Equipamento equipamento)
        {
            ContextoDapper.Conectar();
            var resultado = ContextoDapper.Conexao.Update(equipamento);
            ContextoDapper.Desconectar();
            return resultado;
        }
        public long CriarNovoEquipamento(Equipamento equipamento)
        {
            ContextoDapper.Conectar();
            var resultado = ContextoDapper.Conexao.Insert<Equipamento>(equipamento);
            ContextoDapper.Desconectar();
            return resultado;
        }
        public bool ExcluirEquipamento(Equipamento equipamento)
        {
            ContextoDapper.Conectar();
            var resultado = ContextoDapper.Conexao.Delete(equipamento);
            ContextoDapper.Desconectar();
            return resultado;

        }
        public Equipamento ListarPorId(int Id)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Get<Equipamento>(Id);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public List<Equipamento> ListarTodos(string NomeEquipamento)
        {
            try
            {
                var query = EquipamentoQueryAjuda.ListarTodos();
                var parametros = new Dictionary<string, object>();



                parametros.Add("NomeEquipamento", NomeEquipamento);

                ContextoDapper.Conectar();

                var resultado = ContextoDapper.Conexao.Query<Equipamento>(query, parametros).ToList();

                ContextoDapper.Desconectar();

                return resultado;
            }

            catch (Exception)
            {
                return new List<Equipamento>();
            }
        }
    }
}

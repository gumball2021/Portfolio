﻿using Compartilhado.Entidade;
using Flunt.Validations;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio.Equipamento
{
    [Table("Equipamento")]
    public class Equipamento : Entidade, IEntidade
    {
        DateTime DataHoraAtual = DateTime.Now;
        public string NomeEquipamento { get; private set; }
        public int IdTipo { get; private set; }
        public DateTime? DataGarantia { get; private set; }
        public DateTime DataCompra { get; private set; }
      
        public Equipamento(string nomeEquipamento,int idTipo, string dataGarantia, string dataCompra)
        {
            
            NomeEquipamento = nomeEquipamento;
            IdTipo = idTipo;
            DataGarantia = DateTime.Parse(dataGarantia);
            DataCompra = DateTime.Parse(dataCompra);

            Validar();

        }
        public Equipamento()
        {
        }
        public void Validar()
        {
            if (DataCompra != null && DataGarantia != null)
                if (DataGarantia < DataCompra)
                    AddNotification("Equipamento.Garantia", "Data não corresponde.");

            if (NomeEquipamento == null)
                AddNotifications(new Contract()
                    .Requires()
                    .IsNullOrEmpty(NomeEquipamento, "Equipamento.NomeEquipamento", "Nome Inválido"));
        }
    }
}
//public Equipamento(int id, string nomeEquipamento, int idTipo, DateTime? dataGarantia, DateTime dataCompra)
//{
//    if (id != 0)
//        Id = id;
//    NomeEquipamento = nomeEquipamento;
//    IdTipo = idTipo;
//    DataGarantia = dataGarantia;
//    DataCompra = dataCompra;


//    Validar();


//}
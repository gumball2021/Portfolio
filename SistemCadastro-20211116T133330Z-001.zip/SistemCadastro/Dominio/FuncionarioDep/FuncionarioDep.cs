﻿using Compartilhado.Entidade;
using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio.FuncionarioDep
{

    public class FuncionarioDep:Entidade, IEntidade
    {
        public FuncionarioDep(int iDFuncionario, int iDDepartamento)
        {
            IDFuncionario = iDFuncionario;
            IDDepartamento = iDDepartamento;
        }

        public int IDFuncionario { get; set; }
        public int IDDepartamento { get; set; }
    }
}

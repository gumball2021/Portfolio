﻿using Compartilhado.Entidade;
using Dominio.Estoque.Enum;
using Flunt.Validations;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio.Estoque
{
    [Table("Estoque")]
    public class Estoque : Entidade, IEntidade
    {
        public int Quantidade { get; private set; }
        public int Status { get; private set; }
        public int IDEquipamento { get; private set; }
        public int IDFuncDep { get; private set; }
        public Estoque(int quantidade, int status, int iDEquipamento, int iDFuncDep)
        {
            Quantidade = quantidade;
            if (status == 0)
                Status = (int)EStatusEstoque.EmEstoque;
            IDEquipamento = iDEquipamento;
            IDFuncDep = iDFuncDep;

        }
        public Estoque() { }

        public void Validar()
        {
            if (Quantidade <= 0)
                AddNotification("Estoque.Quantidade", "Quantidade obrigatória.");
        }
    }

}



﻿using Dominio.Estoque;
using SistemCadastro.Dominio.Estoques.Repositorio;
using System;
using System.Collections.Generic;
using System.Text;

namespace SistemCadastro.Dominio.Estoques.Fluxo
{
    public class EstoqueFluxo
    {
        public static bool CriarUmNovoEstoque(Estoque estoque)
        {
            var estoqueRepo = new EstoqueRepositorio();

            var retorno = estoqueRepo.CriarNovoEstoque(estoque);

            if (retorno > 0)
                return true;

            return false;
        }
        public static List<Estoque> ListarTodos()
        {
            var estoqueRepo = new EstoqueRepositorio();
            var resultado = estoqueRepo.ListarTodos();

            return resultado;
        }
    }
}

﻿namespace Dominio.Estoque.Enum
{
    public enum EStatusEstoque
    {
        EmEstoque = 1,                        
        EmUso = 2
    }
}



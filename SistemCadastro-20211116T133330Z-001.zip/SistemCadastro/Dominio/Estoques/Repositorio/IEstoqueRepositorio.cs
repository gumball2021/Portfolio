﻿using Dominio.Estoque;
using System.Collections.Generic;

namespace SistemCadastro.Dominio.Estoques.Repositorio
{
    public interface IEstoqueRepositorio
    {
        bool AlterarEstoque(Estoque estoque);
        long CriarNovoEstoque(Estoque estoque);
        bool ExcluirEstoque(Estoque estoque);
        Estoque ListarPorId(int Id);
        List<Estoque> ListarTodos();
    }
}

﻿using Dapper;
using Dapper.Contrib.Extensions;
using Dominio.Estoque;
using SistemCadastro.Dominio.Departamentos;
using SistemCadastro.Infraestrutura.Contextos.Estoque.QueryAjuda;
using SistemCadastro.Infraestrutura.Dados.Contexto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SistemCadastro.Dominio.Estoques.Repositorio
{
    public class EstoqueRepositorio : IEstoqueRepositorio

    {
        public ContextoBanco ContextoDapper { get; set; }


        public EstoqueRepositorio()
        {
            ContextoDapper = new ContextoBanco();
        }
        public bool AlterarEstoque(Estoque estoque)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Update<Estoque>(estoque);

            ContextoDapper.Desconectar();

            return resultado;
        }

        public long CriarNovoEstoque(Estoque estoque)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Insert<Estoque>(estoque);

            ContextoDapper.Desconectar();

            return resultado;
        }

        public bool ExcluirEstoque(Estoque estoque)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Delete<Estoque>(estoque);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public Estoque ListarPorId(int Id)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Get<Estoque>(Id);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public List<Estoque> ListarTodos()
        {
            try
            {
                var query = EstoqueQueryAjuda.ListarTodos();
                var parametros = new Dictionary<string, object>();



                //parametros.Add("NomeDep", NomeDep);

                ContextoDapper.Conectar();

                var resultado = ContextoDapper.Conexao.Query<Estoque>(query, parametros).ToList();

                ContextoDapper.Desconectar();

                return resultado;
            }

            catch (Exception)
            {
                return new List<Estoque>();
            }
        }
    }
}

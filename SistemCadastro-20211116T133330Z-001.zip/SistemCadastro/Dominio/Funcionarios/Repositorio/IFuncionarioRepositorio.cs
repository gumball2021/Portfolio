﻿using Dominio.Funcionario;
using System;
using System.Collections.Generic;
using System.Text;

namespace SistemCadastro.Dominio.Funcionarios.Repositorio
{
    public interface IFuncionarioRepositorio
    {
        bool AlterarFuncionario(Funcionario funcionario);
        long CriarNovoFuncionario(Funcionario funcionario);
        bool ExcluirFuncionario(Funcionario funcionario);
        Funcionario ListarPorId(int Id);
        List<Funcionario> ListarTodos();
    }
}

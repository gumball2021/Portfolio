﻿using Dapper;
using Dapper.Contrib.Extensions;
using Dominio.Funcionario;
using SistemCadastro.Infraestrutura.Contextos.Funcionario.QueryAjuda;
using SistemCadastro.Infraestrutura.Dados.Contexto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SistemCadastro.Dominio.Funcionarios.Repositorio
{
    public class FuncionarioRepositorio : IFuncionarioRepositorio
    {
        public ContextoBanco ContextoDapper { get; set; }


        public FuncionarioRepositorio()
        {
            ContextoDapper = new ContextoBanco();
        }

        public bool AlterarFuncionario(Funcionario funcionario)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Update<Funcionario>(funcionario);

            ContextoDapper.Desconectar();

            return resultado;
        }

        public long CriarNovoFuncionario(Funcionario funcionario)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Insert<Funcionario>(funcionario);

            ContextoDapper.Desconectar();

            return resultado;
        }

        public bool ExcluirFuncionario(Funcionario funcionario)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Delete<Funcionario>(funcionario);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public Funcionario ListarPorId(int Id)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Get<Funcionario>(Id);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public List<Funcionario> ListarTodos()
        {
            try
            {
                var query = FuncionarioQueryAjuda.ListarTodos();
                var parametros = new Dictionary<string, object>();



                //parametros.Add("NomeDep", NomeDep);

                ContextoDapper.Conectar();

                var resultado = ContextoDapper.Conexao.Query<Funcionario>(query, parametros).ToList();

                ContextoDapper.Desconectar();

                return resultado;
            }

            catch (Exception)
            {
                return new List<Funcionario>();
            }
        }
    }
}

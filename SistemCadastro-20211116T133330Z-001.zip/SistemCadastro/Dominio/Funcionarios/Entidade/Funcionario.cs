﻿using Compartilhado.Entidade;
using Flunt.Validations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Dominio.Funcionario
{
    [Table("Funcionario")]
    public class Funcionario : Entidade, IEntidade
    {
        public string NomeFuncionario { get; private set; }
        public int IDCargo { get; private set; }
        public int IDEmpresa { get; private set; }

        public Funcionario(string nomeFuncionario, int iDCargo, int iDEmpresa)
        {
            NomeFuncionario = nomeFuncionario;
            IDCargo = iDCargo;
            IDEmpresa = iDEmpresa;
        }
        public Funcionario() { }
        public void Validar()
        {
            AddNotifications(new Contract()
                .Requires()
                .IsNullOrEmpty(NomeFuncionario, "Funcionario.NomeFuncionario", "É necessário inserir o nome. "));
        }
    }

}


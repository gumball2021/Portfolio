﻿using Dominio.Funcionario;
using SistemCadastro.Dominio.Funcionarios.Repositorio;
using System;
using System.Collections.Generic;
using System.Text;

namespace SistemCadastro.Dominio.Funcionarios.Fluxo
{
    public class FuncionarioFluxo
    {
        public static bool CriarUmNovoFuncionario(Funcionario funcionario)
        {
            var funcionarioRepo = new FuncionarioRepositorio();
            var retorno = funcionarioRepo.CriarNovoFuncionario(funcionario);
                if (retorno > 0)
                return true;

            return false;
        }
        public static List<Funcionario> ListarTodos()
        {
            var funcionarioRepo = new FuncionarioRepositorio();
            var resultado = funcionarioRepo.ListarTodos();

            return resultado;
        }
    }
}

﻿using Dominio.Especificacao;
using System.Collections.Generic;

namespace SistemCadastro.Dominio.Especificacoes.Repositorio
{
    public interface IEspecificacaoRepositorio
    {
        bool AlterarEspecificacao(Especificacao especificacao);
        long CriarNovaEspecificacao(Especificacao especificacao);
        bool ExcluirEspecificacao(Especificacao especificacao);
        Especificacao ListarPorId(int Id);
        List<Especificacao> ListarTodos();

    }
}

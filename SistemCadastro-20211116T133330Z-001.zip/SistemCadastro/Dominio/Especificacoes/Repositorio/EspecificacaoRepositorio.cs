﻿using Dapper;
using Dapper.Contrib.Extensions;
using Dominio.Especificacao;
using SistemCadastro.Infraestrutura.Contextos.Especificacao.QueryAjuda;
using SistemCadastro.Infraestrutura.Dados.Contexto;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SistemCadastro.Dominio.Especificacoes.Repositorio
{
    public class EspecificacaoRepositorio : IEspecificacaoRepositorio
    {
        public ContextoBanco ContextoDapper { get; set; }

        public EspecificacaoRepositorio()
        {
            ContextoDapper = new ContextoBanco();
        }
        public bool AlterarEspecificacao(Especificacao especificacao)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Update<Especificacao>(especificacao);

            ContextoDapper.Desconectar();

            return resultado;
        }

        public long CriarNovaEspecificacao(Especificacao especificacao)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Insert<Especificacao>(especificacao);

            ContextoDapper.Desconectar();

            return resultado;
        }

        public bool ExcluirEspecificacao(Especificacao especificacao)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Delete<Especificacao>(especificacao);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public Especificacao ListarPorId(int Id)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Get<Especificacao>(Id);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public List<Especificacao> ListarTodos()
        {
            try
            {
                var query = EspecificacaoQueryAjuda.ListarTodos();
                var parametros = new Dictionary<string, object>();



                //parametros.Add("NomeDep", NomeDep);

                ContextoDapper.Conectar();

                var resultado = ContextoDapper.Conexao.Query<Especificacao>(query, parametros).ToList();

                ContextoDapper.Desconectar();

                return resultado;
            }

            catch (Exception)
            {
                return new List<Especificacao>();
            }
        }
    }
}
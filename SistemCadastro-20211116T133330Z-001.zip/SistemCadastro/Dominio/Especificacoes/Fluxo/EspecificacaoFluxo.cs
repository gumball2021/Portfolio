﻿using Dominio.Especificacao;
using SistemCadastro.Dominio.Especificacoes.Repositorio;
using System.Collections.Generic;

namespace SistemCadastro.Dominio.Especificacoes.Fluxo
{
    public class EspecificacaoFluxo
    {
        public static bool CriarUmaNovaEspecificacao(Especificacao especificacao)
        {
            var especificacaoRepo = new EspecificacaoRepositorio();
            var retorno = especificacaoRepo.CriarNovaEspecificacao(especificacao);
            if (retorno > 0)
                return true;

            return false;
        }

        public static List<Especificacao> ListarTodos()
        {
            var especificacaoRepo = new EspecificacaoRepositorio();
            var resultado = especificacaoRepo.ListarTodos();

            return resultado;
        }
    }
}
﻿using Compartilhado.Entidade;
using Flunt.Validations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio.Especificacao
{
    [Table ("Especificacao")]
    public class Especificacao : Entidade, IEntidade
    {        
        public string Marca { get; private set; }
        public string Modelo { get; private set; }
        public string NumSerie { get; private set; }
        public string Observacao { get; private set; }

        public Especificacao(string marca, string modelo, string numSerie, string observacao)
        {
         
            Marca = marca;
            Modelo = modelo;
            NumSerie = numSerie;
            Observacao = observacao;

        }
        public Especificacao() { }

        public void Validar()
        {
            if ((NumSerie == null))
                AddNotification("Especificacao.numSerie", "Campo Obrigatório.");

            AddNotifications(new Contract()
                .Requires()
                .IsNullOrEmpty(Marca, "Especificacao.marca", "Campo inválido."));

            AddNotifications(new Contract()
                .Requires()
                .IsNullOrEmpty(Modelo, "Especificacao.modelo", "Campo inválido."));
        }
    }


}



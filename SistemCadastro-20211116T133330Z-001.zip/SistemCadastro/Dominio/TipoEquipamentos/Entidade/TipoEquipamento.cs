﻿using Compartilhado.Entidade;
using Flunt.Validations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Dominio.TipoEquipamento
{[Table("TipoDeEquipamento")]
    public class TipoEquipamento : Entidade, IEntidade
    {
        public string NomeTipo { get; private set; }
        public int IDTipo { get; private set; }
        public TipoEquipamento(string nomeTipo, int iDTipo)
        {
            NomeTipo = nomeTipo;
            IDTipo = iDTipo;

        }
        public TipoEquipamento() { }

        public void Validar()
        {
            AddNotifications(new Contract()
           .Requires()
           .IsNullOrEmpty(NomeTipo, "TipoEquipamento.NomeTipo", "Campo Obrigatório."));
        }
    }

}





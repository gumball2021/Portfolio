﻿using Dominio.TipoEquipamento;
using System;
using System.Collections.Generic;
using System.Text;

namespace SistemCadastro.Dominio.TipoEquipamentos.Repositorio
{
    public interface ITipoEquipamentoRepositorio
    {
        bool AlterarTipo(TipoEquipamento tipoEquipamento);
        long CriarNovoTipo(TipoEquipamento tipoEquipamento);
        bool ExcluirTipo(TipoEquipamento tipoEquipamento);
        TipoEquipamento ListarPorId(int Id);
        List<TipoEquipamento> ListarTodos();
    }
}

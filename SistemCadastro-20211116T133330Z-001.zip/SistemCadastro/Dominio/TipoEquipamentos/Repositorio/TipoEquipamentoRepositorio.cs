﻿using Dapper;
using Dapper.Contrib.Extensions;
using Dominio.TipoEquipamento;
using SistemCadastro.Dominio.TipoEquipamentos.Repositorio;
using SistemCadastro.Infraestrutura.Contextos.TipoEquipamento.QueryAjuda;
using SistemCadastro.Infraestrutura.Dados.Contexto;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SistemCadastro.Dominio.TipoEquipamentos
{
    public class TipoEquipamentoRepositorio : ITipoEquipamentoRepositorio
    {
        public ContextoBanco ContextoDapper { get; set; }


        public TipoEquipamentoRepositorio()
        {
            ContextoDapper = new ContextoBanco();
        }

        public bool AlterarTipo(TipoEquipamento tipoEquipamento)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Update(tipoEquipamento);

            ContextoDapper.Desconectar();

            return resultado;
        }

        public long CriarNovoTipo(TipoEquipamento tipoEquipamento)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Insert(tipoEquipamento);

            ContextoDapper.Desconectar();

            return resultado;
        }

        public bool ExcluirTipo(TipoEquipamento tipoEquipamento)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Delete(tipoEquipamento);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public TipoEquipamento ListarPorId(int Id)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Get<TipoEquipamento>(Id);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public List<TipoEquipamento> ListarTodos()
        {
            try
            {
                var query = TipoEquipamentoQueryAjuda.ListarTodos();
                var parametros = new Dictionary<string, object>();



                // parametros.Add("NomeDep", NomeDep);

                ContextoDapper.Conectar();

                var resultado = ContextoDapper.Conexao.Query<TipoEquipamento>(query, parametros).ToList();

                ContextoDapper.Desconectar();

                return resultado;
            }

            catch (Exception ex)
            {
                return new List<TipoEquipamento>();
            }
        }
    }
}
﻿using Dominio.TipoEquipamento;
using System;
using System.Collections.Generic;
using System.Text;

namespace SistemCadastro.Dominio.TipoEquipamentos
{
   public class TipoEquipamentoFluxo
    {
        public static bool CriarUmNovoTipo(TipoEquipamento tipoequipamento)
        {
            var tipoRepo = new TipoEquipamentoRepositorio();

            var retorno = tipoRepo.CriarNovoTipo(tipoequipamento);

            if (retorno > 0)
                return true;

            return false;
        }
        public static List<TipoEquipamento> ListarTodos()
        {
            var tipoRepo = new TipoEquipamentoRepositorio();
            var resultado = tipoRepo.ListarTodos();

            return resultado;
        }

    }
}

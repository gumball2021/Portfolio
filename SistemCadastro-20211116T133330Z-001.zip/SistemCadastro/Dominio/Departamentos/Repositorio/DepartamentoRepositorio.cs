﻿using SistemCadastro.Infraestrutura.Dados.Contexto;
using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using Dapper;
using SistemCadastro.Infraestrutura.Contextos.Departamento.QueryAjuda;
using System.Linq;

namespace SistemCadastro.Dominio.Departamentos.Repositorio
{
    public class DepartamentoRepositorio : IDepartamentoRepositorio
    {
        public ContextoBanco ContextoDapper { get; set; }

        public DepartamentoRepositorio()
        {
            ContextoDapper = new ContextoBanco();
        }

        public long CriarNovoDepartamento(Departamento departamento)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Insert<Departamento>(departamento);

            ContextoDapper.Desconectar();

            return resultado;
        }

        public bool AlterarDepartamento(Departamento departamento)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Update<Departamento>(departamento);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public bool ExcluirDepartamento(Departamento departamento)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Delete<Departamento>(departamento);

            ContextoDapper.Desconectar();

            return resultado;

        }
        public Departamento ListarPorId(int Id)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Get<Departamento>(Id);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public List<Departamento> ListarTodos(string NomeDep)
        {
            try
            {
                var query = DepartamentoQueryAjuda.ListarTodos();
                var parametros = new Dictionary<string, object>();



                parametros.Add("NomeDep", NomeDep);

                ContextoDapper.Conectar();

                var resultado = ContextoDapper.Conexao.Query<Departamento>(query, parametros).ToList();

                ContextoDapper.Desconectar();

                return resultado;
            }

            catch (Exception)
            {
                return new List<Departamento>();
            }
        }
    }
}


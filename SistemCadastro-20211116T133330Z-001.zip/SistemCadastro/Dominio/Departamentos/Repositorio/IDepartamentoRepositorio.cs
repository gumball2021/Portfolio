﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SistemCadastro.Dominio.Departamentos.Repositorio
{
   public interface IDepartamentoRepositorio
    {
        long CriarNovoDepartamento(Departamento departamento);
        bool AlterarDepartamento(Departamento departamento);
        bool ExcluirDepartamento(Departamento departamento);
        Departamento ListarPorId(int Id);
        List<Departamento> ListarTodos(string NomeDepartamento);
    }
}

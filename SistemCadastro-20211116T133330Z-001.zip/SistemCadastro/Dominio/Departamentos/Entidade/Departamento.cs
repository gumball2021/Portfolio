﻿using Compartilhado.Entidade;
using Flunt.Validations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SistemCadastro.Dominio.Departamentos
{ 
    [Table ("Departamento")]
    public class Departamento : Entidade, IEntidade
    {
        public string NomeDep { get; private set; }
        public Departamento(string nomeDep)
        {
            NomeDep = nomeDep;
           
        }

        public Departamento()
        {

        }

        public void Validar()
        {

            AddNotifications(new Contract()
                .Requires()
                .IsNullOrEmpty(NomeDep, "Departamento.NomeDep", "Insira um Setor."));

        }
    }
}

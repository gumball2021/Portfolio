﻿using SistemCadastro.Dominio.Departamentos.Repositorio;
using System.Collections.Generic;

namespace SistemCadastro.Dominio.Departamentos.Fluxo
{
    public class DepartamentoFluxo
        {
        public static bool CriarUmNovoDepartamento(Departamento departamento)
        {
            var cargoRepo = new DepartamentoRepositorio();

            var retorno = cargoRepo.CriarNovoDepartamento(departamento);

            if (retorno > 0)
                return true;

            return false;
        }
        public static Departamento ListarPorId(int Id)
        {
            var departamentoRepo = new DepartamentoRepositorio();

            var resultado = departamentoRepo.ListarPorId(Id);

            return resultado;
        }
        public static List<Departamento> ListarTodos(string NomeDep)
        {
            var departamentoRepo = new DepartamentoRepositorio();
            var resultado = departamentoRepo.ListarTodos(NomeDep);

            return resultado;
        }
         public static Departamento Alterar(string NomeDep)
        {   
            var departamentoRepo = new DepartamentoRepositorio();
            var resultado = departamentoRepo.AlterarDepartamento( NomeDep);

            return resultado;
        }
        public static Departamento Excluir()
        {   
            var departamentoRepo = new DepartamentoRepositorio();
            var resultado = departamentoRepo.ExcluirDepartamento();

            return resultado;
        }
    }
}

   

﻿using Flunt.Notifications;
using Flunt.Validations;
using SistemCadastro.Dominio.Departamentos.Comando;

namespace SistemCadastro.Dominio.Cargos.Comando
{
    public class AlterarCargoComando : Notifiable, IComando
    {
        public AlterarCargoComando(int id, bool estaAtivo, string nomeCargo)
        {
            Id = id;
            EstaAtivo = estaAtivo;
            NomeCargo = nomeCargo;
        }

        public int Id { get; set; }
        public bool EstaAtivo { get; set; }
        public string NomeCargo { get; set; }
        public void Validar() => AddNotifications(new Contract()
                .Requires()
                .IsNotNullOrEmpty(Id.ToString(), "Id", "O identificador único do cargo é inválido")
                .IsNotNullOrEmpty(NomeCargo, "Cargo.NomeCargo", "Necessário Informar o Cargo.")
                .IsLowerThan(NomeCargo.Length, 5, "NomeCargo", "O nome do cargo não pode conter menos que 5 caracteres."));

    }
}
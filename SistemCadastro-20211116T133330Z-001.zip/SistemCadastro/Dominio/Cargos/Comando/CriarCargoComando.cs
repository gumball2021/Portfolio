﻿using Flunt.Notifications;
using Flunt.Validations;
using SistemCadastro.Dominio.Departamentos.Comando;

namespace SistemCadastro.Dominio.Cargos.Comando
{
    public class CriarCargoComando : Notifiable, IComando
    {
        public string NomeCargo { get; set; }

        public CriarCargoComando(string nomeCargo)
        {
            NomeCargo = nomeCargo;
            Validar();

        }

        public void Validar()
        {
            AddNotifications(new Contract()
               .Requires()
               .IsNotNullOrEmpty(NomeCargo, "Cargo.NomeCargo", "Necessário Informar o Cargo."));
        }
    }
}

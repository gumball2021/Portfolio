﻿using Flunt.Notifications;
using Flunt.Validations;
using SistemCadastro.Dominio.Departamentos.Comando;

namespace SistemCadastro.Dominio.Cargos.Comando
{
   public class ExcluirCargoComando:Notifiable, IComando
    {
        public int Id { get; set; }
        public ExcluirCargoComando(int id) => Id = id;

        public void Validar()
        {
            AddNotifications(new Contract()
                .Requires()
                .IsNotNullOrEmpty(Id.ToString(), "Id", "Cargo não encontrado."));
        }
    }
}

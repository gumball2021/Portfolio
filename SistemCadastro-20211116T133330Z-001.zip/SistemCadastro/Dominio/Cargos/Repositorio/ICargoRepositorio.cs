﻿using Dominio.Cargos;
using SistemCadastro.Dominio.Cargos.Queries;
using System.Collections.Generic;

namespace SistemCadastro.Dominio.Departamentos.Repositorio
{
    public interface ICargoRepositorio
    {
        long CriarNovoCargo(Cargo cargo);
        bool AlterarCargo(Cargo cargo);
        bool ExcluirCargo(Cargo cargo);
        Cargo ListarPorId(int Id);
        List<Cargo> ListarTodos(string NomeCargo);

        

    }
}

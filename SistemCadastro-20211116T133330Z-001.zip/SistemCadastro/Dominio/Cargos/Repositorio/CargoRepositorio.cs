﻿using Dapper;
using Dapper.Contrib.Extensions;
using Dominio.Cargos;
using SistemCadastro.Dominio.Departamentos.Repositorio;
using SistemCadastro.Infraestrutura.Contextos.Cargo.QueryAjuda;
using SistemCadastro.Infraestrutura.Dados.Contexto;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SistemCadastro.Dominio.Cargos.Repositorio
{

    public class CargoRepositorio : ICargoRepositorio
    {
        public ContextoBanco ContextoDapper { get; set; }


        public CargoRepositorio()
        {
            ContextoDapper = new ContextoBanco();
        }


        public long CriarNovoCargo(Cargo cargo)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Insert<Cargo>(cargo);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public bool AlterarCargo(Cargo cargo)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Update<Cargo>(cargo);

            ContextoDapper.Desconectar();

            return resultado;
        }

        public bool ExcluirCargo(Cargo cargo)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Delete<Cargo>(cargo);

            ContextoDapper.Desconectar();

            return resultado;

        }
        public Cargo ListarPorId(int Id)
        {
            ContextoDapper.Conectar();

             var resultado = ContextoDapper.Conexao.Get<Cargo>(Id);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public List<Cargo> ListarTodos(string NomeCargo)
        {
            try
            {
                var query = CargoQueryAjuda.ListarTodos();
                var parametros = new Dictionary<string, object>();


                
                parametros.Add("NomeCargo", NomeCargo);

                ContextoDapper.Conectar();

                var resultado = ContextoDapper.Conexao.Query<Cargo>(query, parametros).ToList();

                ContextoDapper.Desconectar();

                return resultado;
            }

            catch (Exception)
            {
                return new List<Cargo>();
            }

        }

       

        //public CargoListagemQuery GetCargoListagemQuery(string nomeCargo)
        //{
        //    return ContextoDapper
        //        .Conexao
        //        .Query<CargoListagemQuery>("cargo",
        //        new { Nomecargo = nomeCargo });

        //}
    }
}

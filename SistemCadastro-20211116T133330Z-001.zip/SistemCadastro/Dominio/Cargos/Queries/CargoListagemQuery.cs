﻿using Compartilhado.Entidade;
using System;
using System.Collections.Generic;
using System.Text;

namespace SistemCadastro.Dominio.Cargos.Queries
{
    public class CargoListagemQuery
    {
        public int Id { get; set; }
        public string NomeCargo { get; set; }
        public DateTime DataCadastro { get; set; }
        public bool EstaAtivo { get; set; }

    }
}

﻿using Dominio.Cargos;
using SistemCadastro.Dominio.Cargos.Repositorio;
using System;
using System.Collections.Generic;
using System.Text;

namespace SistemCadastro.Dominio.Cargos.Fluxo
{
    public class CargoFluxo
    {
        public static object Conexao { get; set; }

        public static bool CriarUmNovoCargo(Cargo cargo)
        {
            var cargoRepo = new CargoRepositorio();

            var retorno = cargoRepo.CriarNovoCargo(cargo);

            if (retorno > 0)
                return true;

            return false;
        }
        public static Cargo ListarPorId(int Id)
        {
            var cargoRepo = new CargoRepositorio();

            var resultado = cargoRepo.ListarPorId(Id);                     

            return resultado;
        }
        public static List<Cargo> ListarTodos(string NomeCargo)
        {
            var cargoRepo = new CargoRepositorio();
            var resultado = cargoRepo.ListarTodos( NomeCargo);

            return resultado;
        }
        public static Cargo Alterar(string NomeCargo)
        {   
            var cargoRepo = new CargoRepositorio();
            var resultado = cargoRepo.AlterarCargo( NomeCargo);

            return resultado;
        }
        public static Cargo Excluir()
        {   
            var cargoRepo = new CargoRepositorio();
            var resultado = cargoRepo.ExcluirCargo();

            return resultado;
        }

    }
}  

﻿using Compartilhado.Entidade;
using Flunt.Validations;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dominio.Cargos
{
    [Table("Cargo")]
    public class Cargo : Entidade, IEntidade
    {

        public string NomeCargo { get; set; }


        public Cargo(int id, string nomeCargo, DateTime dataCadastro, bool estaAtivo)
        {
            Id = id;
            NomeCargo = nomeCargo;
            DataCadastro = DateTime.UtcNow.AddHours(-3);
            EstaAtivo = estaAtivo;
        }

        public Cargo()
        {
        }




        public void Validar()
        {
            AddNotifications(new Contract()
               .Requires()
               .IsNullOrEmpty(NomeCargo, "Cargo.NomeCargo", "Necessário Informar o Cargo."));
        }
    }
}

﻿using Dapper;
using Dapper.Contrib.Extensions;
using Dominio.Empresa;
using SistemCadastro.Infraestrutura.Contextos.Empresa.QueryAjuda;
using SistemCadastro.Infraestrutura.Dados.Contexto;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SistemCadastro.Dominio.Empresas.Repositorio
{
    public class EmpresaRepositorio : IEmpresaRepositorio
    {
        public ContextoBanco ContextoDapper { get; set; }

        public EmpresaRepositorio()
        {
            ContextoDapper = new ContextoBanco();
        }

        public bool AlterarEmpresa(Empresa empresa)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Update(empresa);

            ContextoDapper.Desconectar();

            return resultado;
        }

        public long CriarNovaEmpresa(Empresa empresa)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Insert(empresa);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public bool ExcluirEmpresa(Empresa empresa)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Delete(empresa);

            ContextoDapper.Desconectar();

            return resultado;

        }
        public Empresa ListarPorId(int Id)
        {
            ContextoDapper.Conectar();

            var resultado = ContextoDapper.Conexao.Get<Empresa>(Id);

            ContextoDapper.Desconectar();

            return resultado;
        }
        public List<Empresa> ListarTodos(string NomeEmpresa)
        {
            try
            {
                var query = EmpresaQueryAjuda.ListarTodos();
                var parametros = new Dictionary<string, object>();



                parametros.Add("NomeEmpresa", NomeEmpresa);

                ContextoDapper.Conectar();

                var resultado = ContextoDapper.Conexao.Query<Empresa>(query, parametros).ToList();

                ContextoDapper.Desconectar();

                return resultado;
            }

            catch (Exception)
            {
               return new List<Empresa>();
            }
        }
    }
}
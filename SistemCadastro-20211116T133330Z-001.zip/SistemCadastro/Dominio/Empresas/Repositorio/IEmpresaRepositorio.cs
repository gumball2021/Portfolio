﻿using Dominio.Empresa;
using System;
using System.Collections.Generic;
using System.Text;

namespace SistemCadastro.Dominio.Empresas.Repositorio
{
    public interface IEmpresaRepositorio
    {
        long CriarNovaEmpresa(Empresa empresa);
        bool AlterarEmpresa(Empresa empresa);
        bool ExcluirEmpresa(Empresa empresa);
        Empresa ListarPorId(int Id);
        List<Empresa> ListarTodos(string NomeEmpresa);
    }
}

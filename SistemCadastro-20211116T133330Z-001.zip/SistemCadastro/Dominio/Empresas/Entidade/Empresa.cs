﻿using Compartilhado.Entidade;
using Flunt.Validations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Dominio.Empresa
{
    [Table ("Empresa")]
    public class Empresa : Entidade, IEntidade
    {
        public string NomeEmpresa { get; private set; }
        public Empresa(string nomeEmpresa)
        {
            NomeEmpresa = nomeEmpresa;
                       
        }
        public Empresa()
        {
        }
        public void Validar()
        {
            AddNotifications(new Contract()
                .Requires()
                .IsNullOrEmpty(NomeEmpresa, "Empresa.NomeEmpresa", "Insira o nome da Empresa."));

        }
    }

}

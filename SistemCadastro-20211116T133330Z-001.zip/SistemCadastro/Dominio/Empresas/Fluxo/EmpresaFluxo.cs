﻿using Dominio.Empresa;
using SistemCadastro.Dominio.Empresas.Repositorio;
using System;
using System.Collections.Generic;
using System.Text;

namespace SistemCadastro.Dominio.Empresas.Fluxo
{
    public class EmpresaFluxo
    {
        public static bool CriarUmaNovaEmpresa(Empresa empresa)
        {
            var empresaRepo = new EmpresaRepositorio();

            var retorno = empresaRepo.CriarNovaEmpresa(empresa);

            if (retorno > 0)
                return true;

            return false;
        }
        public static Empresa ListarPorId(int Id)
        {
            var empresaRepo = new EmpresaRepositorio();

            var resultado = empresaRepo.ListarPorId(Id);

            return resultado;
        }
        public static List<Empresa> ListarTodos(string NomeEmpresa)
        {
            var empresaRepo = new EmpresaRepositorio();
            var resultado = empresaRepo.ListarTodos(NomeEmpresa);

            return resultado;
        }
         public static Empresa Alterar(string NomeEmpresa)
        {   
            var empresaRepo = new EmpresaRepositorio();
            var resultado = empresaRepo.AlterarEmpresa(NomeEmpresa);

            return resultado;
        }
        public static Empresa Excluir()
        {   
            var empresaRepo = new EmpresaRepositorio();
            var resultado = empresaRepo.ExcluirEmpresa();

            return resultado;
        }
    }
}


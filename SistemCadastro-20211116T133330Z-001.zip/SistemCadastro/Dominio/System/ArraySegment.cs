﻿namespace System
{
    internal class ArraySegment
    {
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SistemCadastro.Compartilhado.Configuracoes
{
    public class ConfiguracaoDaAplicacao
    {
        public static string StringDeConexaoBancoSqlServer = "Server=QSBR-NB012\\SQLEXPRESS;Database=DB_SI;User ID=sa;Password=d@ny1987";
    }
}

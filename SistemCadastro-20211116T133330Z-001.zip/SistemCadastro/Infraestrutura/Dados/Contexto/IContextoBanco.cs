﻿namespace Dados.Contexto
{
    public interface IContextoBanco
    {
    }
}
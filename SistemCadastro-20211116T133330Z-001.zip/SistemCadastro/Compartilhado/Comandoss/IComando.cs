﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SistemCadastro.Dominio.Cargos.Repositorio
{
    public interface IComando
    {
        void Validar();
    }
}
